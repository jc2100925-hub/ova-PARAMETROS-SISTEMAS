# OVA: Parámetros de Sistemas (Homeostasis y Equilibrio)

## Autor
Jerry Alexander Castro Rojas

## Asignatura
Teoría General de Sistemas

## Descripción del Proyecto
Esta OVA interactiva permite comprender los **parámetros de los sistemas**, enfocándose en **homeostasis** y **equilibrio dinámico**. Incluye:
- Conceptos teóricos.
- Ejemplos prácticos.
- Juegos interactivos funcionales con gráficos animados.
- Quiz con puntuación automática.
- Videos educativos.

## Herramientas Utilizadas
- HTML5, CSS3, JavaScript
- Canvas API para gráficos interactivos
- Slider y número inputs para simulaciones
- YouTube para videos educativos

## Juegos Interactivos
1. **Homeostasis:** Ajusta niveles de energía para mantener el sistema estable con indicadores visuales en tiempo real.
2. **Equilibrio Dinámico Organizacional:** Balancea recursos (personas, dinero, tiempo) y observa alertas visuales según el estado del sistema.

## Instrucciones para Ejecutar
1. Abrir `index.html` en un navegador moderno (Chrome, Edge, Firefox).  
2. Navegar entre secciones usando el menú superior.  
3. Interactuar con sliders y inputs para probar los juegos.  
4. Completar el quiz para obtener puntuación inmediata.

## Créditos y Referencias
- Bertalanffy, L. von. (1968). *General System Theory*. George Braziller.  
- OIT (2021). *Riesgos ergonómicos y funcionalidad de sistemas humanos*.  
- Llamas-Ramos, J. (2023). *Teoría de sistemas aplicada a entornos organizacionales*.
